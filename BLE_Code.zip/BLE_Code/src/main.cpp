#include <BLEDevice.h>         // Include BLEDevice library
#include <BLEUtils.h>          // Include BLEUtils library
#include <BLEScan.h>           // Include BLEScan library
#include <BLEAdvertisedDevice.h> // Include BLEAdvertisedDevice library
#include <Arduino.h>           // Include Arduino library
#include <HardwareSerial.h>    // Include HardwareSerial library

HardwareSerial SerialPort(2); // Initialize SerialPort object for UART2 communication

BLEScan* pBLEScan; // Pointer to BLEScan object

#define SERVICE_UUID "0000fef3-0000-1000-8000-00805f9b34fb" // UUID of the service

// Class to handle advertised BLE devices
class MyAdvertisedDeviceCallbacks : public BLEAdvertisedDeviceCallbacks {
    void onResult(BLEAdvertisedDevice advertisedDevice) {
        if (advertisedDevice.haveServiceUUID() && advertisedDevice.getServiceUUID().equals(BLEUUID(SERVICE_UUID))) {
            // If advertised device has the specified service UUID
            Serial.println("###########    ################");
            String advertisementData = advertisedDevice.toString().c_str(); // Get advertisement data as a string

            int serviceDataIndex = advertisementData.indexOf("serviceData:"); // Find position of "serviceData"

            if (serviceDataIndex != -1) { // If "serviceData" is found
                int commaIndex = advertisementData.indexOf(',', serviceDataIndex); // Find position of next comma after "serviceData"

                String serviceData = advertisementData.substring(serviceDataIndex, commaIndex); // Extract serviceData substring
                Serial.println("Service Data: " + serviceData); // Print serviceData
                serviceData += "\n";
                SerialPort.print(serviceData); // Send serviceData over UART2
            } else {
                Serial.println("Service Data not found."); // If serviceData is not found
            }
        } else {
            Serial.println("Data Received from other Services"); // If service UUID doesn't match
        }
    }
};

void setup() {
    Serial.begin(115200); // Start serial communication at 115200 baud rate
    SerialPort.begin(15200, SERIAL_8N1, 16, 17); // Start UART2 communication
    Serial.println("Starting BLE Scan..."); // Print message

    BLEDevice::init("test"); // Initialize BLE with a name
    pBLEScan = BLEDevice::getScan(); // Get BLEScan object
    pBLEScan->setAdvertisedDeviceCallbacks(new MyAdvertisedDeviceCallbacks()); // Set advertised device callback
    pBLEScan->setActiveScan(true); // Set active scan mode
    pBLEScan->start(0); // Start scanning with no timeout (continuous scanning)
}

void loop() {
    // Handle any other tasks here
    delay(1000); // Delay for 1 second (adjust as needed)
}
