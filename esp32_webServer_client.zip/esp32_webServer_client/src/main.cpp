#include <Arduino.h>
#include <WiFi.h>
#include <AsyncTCP.h>
#include <ESPAsyncWebServer.h>
#include <LiquidCrystal_I2C.h>

// Replace with your network credentials
const char* ssid = "Neo";
const char* password = "12345678";

const char* PARAM_INPUT_1 = "output";
const char* PARAM_INPUT_2 = "state";

#define Grun 2
#define Gelb 4
#define Rot 5


AsyncWebServer server(80);
LiquidCrystal_I2C lcd (0x27, 16,2);

String outputState(int output){
  if(digitalRead(output)){
    return "checked";
  }
  else {
    return "";
  }
}

const char index_html[] PROGMEM = R"rawliteral(
<!DOCTYPE HTML><html>
<head>
  <title>LED'S</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" href="data:,">
  <style>
    html {font-family: Arial; display: inline-block; text-align: center;}
    h2 {font-size: 3.0rem;}
    p {font-size: 3.0rem;}
    body {max-width: 600px; margin:0px auto; padding-bottom: 25px;}
    .switch {position: relative; display: inline-block; width: 90px; height: 48px} 
    .switch input {display: none}
    .slider {position: absolute; top: 0; left: 0; right: 0; bottom: 0; background-color: #ccc; border-radius: 6px}
    .slider:before {position: absolute; content: ""; height: 32px; width: 32px; left: 8px; bottom: 8px; background-color: #fff; -webkit-transition: .4s; transition: .4s; border-radius: 3px}
    input:checked+.slider {background-color: #0000FF}
    input:checked+.slider:before {-webkit-transform: translateX(32px); -ms-transform: translateX(32px); transform: translateX(32px)}
 .row {
    display: flex; /* Use flexbox to align items horizontally */
    align-items: center; /* Center items vertically */
    justify-content: center;
    margin-bottom: 10px; /* Add some margin between rows, adjust as needed */
}

  </style>
</head>
<body>
  <h2>LED'S</h2>
  <center>
  %BUTTONPLACEHOLDER%

  <h3>Message</h3>
   <input type="text" class="textbox" placeholder="Enter your Message here" id="message" name="message"> <br><br>
   <button onclick="postdata();" style="height: 35px;
    border-radius:10px;"><b>Send</b></button><br><br>
    <h3>Alarm</h3>
      <input type="time" class="textbox" placeholder="Time" id="alrm" name="alrm"> <br><br>
        <button onclick="start();" style="height: 35px;
    border-radius:10px;"><b>Start</b></button>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      <button onclick="stop();" style="height: 35px;
    border-radius:10px;"><b>Stop</b></button><br><br>
  </center>
<script>function toggleCheckbox(element) {
  var xhr = new XMLHttpRequest();
  if(element.checked){ xhr.open("GET", "/update?output="+element.id+"&state=1", true); }
  else { xhr.open("GET", "/update?output="+element.id+"&state=0", true); }
  xhr.send();
}

 function postdata() {

                var msgvalue = document.getElementById("message").value;
   var a = "message";
                var xhr = new XMLHttpRequest();
                xhr.open("GET", "/update?output=" + a + "&state=" + msgvalue, true);
                xhr.send();

              }
</script>
</body>
</html>
)rawliteral";

// Replaces placeholder with button section in your web page
String processor(const String& var){
  //Serial.println(var);
  if(var == "BUTTONPLACEHOLDER"){
   String buttons = "";
   
    buttons+="<div class=\"row\">";
    buttons += "<h4>Grun  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</h4><label class=\"switch\"><input type=\"checkbox\" onchange=\"toggleCheckbox(this)\" id=\"2\" " + outputState(2) + "><span class=\"slider\"></span></label>";
    buttons +="</div>";
    buttons+="<div class=\"row\">";
    buttons += "<h4>Gelb &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  </h4><label class=\"switch\"><input type=\"checkbox\" onchange=\"toggleCheckbox(this)\" id=\"4\" " + outputState(4) + "><span class=\"slider\"></span></label>";
    buttons +="</div>";
    buttons+="<div class=\"row\">";
    buttons += "<h4>Rot &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</h4><label class=\"switch\"><input type=\"checkbox\" onchange=\"toggleCheckbox(this)\" id=\"5\" " + outputState(5) + "><span class=\"slider\"></span></label>";
    buttons +="</div>";
    return buttons;
  }
  return String();
}



void setup(){
  // Serial port for debugging purposes
  Serial.begin(115200);
    // Initialize the LCD connected 
lcd. begin ();
  // Turn on the backlight on LCD. 
  lcd. backlight ();

  pinMode(Grun, OUTPUT);
  digitalWrite(Grun, LOW);
  pinMode(Gelb, OUTPUT);
  digitalWrite(Gelb, LOW);
  pinMode(Rot, OUTPUT);
  digitalWrite(Rot, LOW);
  
  // Connect to Wi-Fi
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(1000);
    Serial.println("Connecting to WiFi..");
  }

  // Print ESP Local IP Address
  Serial.println(WiFi.localIP());

  // Route for root / web page
  server.on("/", HTTP_GET, [](AsyncWebServerRequest *request){
    request->send_P(200, "text/html", index_html, processor);
  });

  // Send a GET request to <ESP_IP>/update?output=<inputMessage1>&state=<inputMessage2>
  server.on("/update", HTTP_GET, [] (AsyncWebServerRequest *request) {
    String inputMessage1;
    String inputMessage2;
    // GET input1 value on <ESP_IP>/update?output=<inputMessage1>&state=<inputMessage2>
    if (request->hasParam(PARAM_INPUT_1) && request->hasParam(PARAM_INPUT_2)) {
      inputMessage1 = request->getParam(PARAM_INPUT_1)->value();
      inputMessage2 = request->getParam(PARAM_INPUT_2)->value();
      digitalWrite(inputMessage1.toInt(), inputMessage2.toInt());
    }
    else {
      inputMessage1 = "No message sent";
      inputMessage2 = "No message sent";
    }
    Serial.print("GPIO: ");
    Serial.print(inputMessage1);
    Serial.print(" - Set to: ");
    Serial.println(inputMessage2);
    if(inputMessage1.indexOf('message')>-1){
      lcd. print(inputMessage2);
    }
    request->send(200, "text/plain", "OK");
  });

  // Start server
  server.begin();
}

void loop() {

}