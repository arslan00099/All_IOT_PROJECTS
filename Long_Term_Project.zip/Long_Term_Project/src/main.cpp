#include <Arduino.h>
#include "next.h"
#include "key.h"
#include "rfidscanner.h"
#include "myntp.h"
#include "flow.h"

#define pump_RELAY 4
String reasonArray[5];
int counter = 0;
int inputKelo;
float value;
 char buffer[10];;


const char *ssid = "Office";
const char *password = "ctitrkt@786";


void setupWifi()
{
  WiFi.begin(ssid, password);
  Serial.println("Connecting");
  while (WiFi.status() != WL_CONNECTED)
  {
    delay(500);
    Serial.print(".");
  }
  Serial.println("");
  Serial.print("Connected to WiFi network with IP Address: ");
  Serial.println(WiFi.localIP());
}

void resetSPIFFS()
{
  SPIFFS.end();
  SPIFFS.format();
  if (!SPIFFS.begin())
  {
    Serial.println("Failed to mount file system");
    return;
  }
}

void handlingMenus()
{
  if (counter < categorySize)
  {
    if (customKey)
    {

      keyvalue = int(customKey);
      Serial.println("KEY VALUE : " + keyvalue);
      if (keyvalue == 68) // D clicked
      {
        p1tb1.setFont(1);
        p1tb2.setFont(1);
        p1tb3.setFont(1);
        p1tb4.setFont(1);
        Serial.println(cpass);
        if (cpass.indexOf("1") > -1)
        {
          reasonArray[counter] = twoDimentionArray[1][counter];
        }
        if (cpass.indexOf("2") > -1)
        {
          reasonArray[counter] = twoDimentionArray[2][counter];
        }
        if (cpass.indexOf("3") > -1)
        {
          reasonArray[counter] = twoDimentionArray[3][counter];
        }
        if (cpass.indexOf("4") > -1)
        {
          reasonArray[counter] = twoDimentionArray[4][counter];
        }
        Serial.println("REASON " + (String)counter+1 + " SELECTED :" + (String)reasonArray[counter]);
        keyvalue = 0;
        counter++;
        Serial.println((String) + counter);
        customKey = 'A';
        if (counter == categorySize)
        {
          Serial2.print("page page2");
          Serial2.write(0xff);
          Serial2.write(0xff);
          Serial2.write(0xff);
          customKey = 'A';
          counter = 5;
        }

        else if (counter == 1)
        {
          showPage2Reason();
        }
        else if (counter == 2)
        {
          showPage3Reason();
        }
        else if (counter == 3)
        {
          showPage4Reason();
        }
        else if (counter == 4)
        {
          showPage5Reason();
        }
      }

      if (keyvalue == 2)
      {
        counter--;
        if (counter == 0)
        {
          showPage1Reason();
        }
        else if (counter == 1)
        {
          showPage2Reason();
        }
        else if (counter == 2)
        {
          showPage3Reason();
        }
        else if (counter == 3)
        {
          showPage4Reason();
        }
        else if (counter == 4)
        {
          showPage5Reason();
        }
      }

      else
      {
        cpass = customKey;
        // Serial.println("KEYVAKE : "+(String)keyvalue);
        if (keyvalue == 49)
        {
          p1tb1.setFont(3);
          p1tb2.setFont(1);
          p1tb3.setFont(1);
          p1tb4.setFont(1);
        }
        else if (keyvalue == 50)
        {
          p1tb1.setFont(1);
          p1tb2.setFont(3);
          p1tb3.setFont(1);
          p1tb4.setFont(1);
        }
        else if (keyvalue == 51)
        {
          p1tb1.setFont(1);
          p1tb2.setFont(1);
          p1tb3.setFont(3);
          p1tb4.setFont(1);
        }
        else if (keyvalue == 52)
        {
          p1tb1.setFont(1);
          p1tb2.setFont(1);
          p1tb3.setFont(1);
          p1tb4.setFont(3);
        }
      }
    }
  }

  if (counter == 5)
  {
    keyvalue = int(customKey);
    // Serial.println((String)keyvalue);
    if (customKey)
    {
      if (keyvalue == 67)
      {
        cpass.remove(cpass.length() - 1);
        p2tb1.setText(cpass.c_str());
      }
      else if (keyvalue == 65)
      {
        String empty = "";
        cpass = "";
        p2tb1.setText(empty.c_str());
      }
      else
      {
        Serial.println(keyvalue);
        keyvalue = int(customKey);
        cpass += customKey;
        p2tb1.setText(cpass.c_str());
      }
    }
    if (cpass.indexOf("D") > -1)
    {

      cpass.remove(cpass.length() - 1);
      p2tb1.setText(cpass.c_str());
      inputKelo = cpass.toInt();
      if ((inputKelo > minkelometers) && (inputKelo < maxkelometers))
      {
        digitalWrite(pump_RELAY, HIGH);
        cpass += "  Good";
        flowFlag = true;
        postMillis=millis();
        p2tb1.setText(cpass.c_str());
        Serial.println("RELAY ON");

      }
      if (inputKelo < minkelometers)
      {
        cpass += "  LOW";
        p2tb1.setText(cpass.c_str());
          cpass="";
      }

      if (inputKelo > maxkelometers)
      {
        cpass += "  HIGH";
        p2tb1.setText(cpass.c_str());
        customKey ='A';
        cpass="";
      }

      Serial.println(cpass);
    }
  }
}

void listMySpiff(){
  Serial.println("######################  LISTING SPIFF #######################");
   File root = SPIFFS.open("/uploadData");
 
  File file = root.openNextFile();
 
  while(file){
 
      Serial.print("FILE: ");
      Serial.println(file.name());
 
      file = root.openNextFile();
  }
    Serial.println("######################  END SPIFF #######################");
}

void uploadSpiffFile(){
   File root = SPIFFS.open("/uploadData");
 
  File file = root.openNextFile();
 
  while(file){
 
      Serial.print("FILE: ");
      Serial.println(file.name());
      String name="/uploadData/"+(String)file.name();
      String serverData=readJSONFromFile(name);
     // Serial.println(serverData);
 postData(serverData);
 SPIFFS.remove(name);
      file = root.openNextFile();
  }
}

void setup()
{
  Serial.begin(115200);
  setupNExtion();
  // resetSPIFFS();
  pinMode(pump_RELAY, OUTPUT);
  digitalWrite(pump_RELAY, LOW);

  SPI.begin();        /*SPI communication initialized*/
  mfrc522.PCD_Init(); /*RFID sensor initialized*/

  if (!SPIFFS.begin(true))
  {
    Serial.println("Failed to mount file system");
    return;
  }
setupFlowSensor();
  getReasonFromSpiff();
  setupWifi();
  getMinMaxFromSpiff();
  getEpoch();
  
  while (epochTime < 1){
  getntp();
}
Serial.println("EPOUCH : "+(String)rtc.getEpoch());


  Serial.println("Approach your reader card...");
  Serial.println();
  Serial2.print("page page0");
  Serial2.write(0xff);
  Serial2.write(0xff);
  Serial2.write(0xff);

listMySpiff();
uploadSpiffFile();


}

void loop()
{

 loopNextion();

  readRFID();
  loopkeypad();
  handlingMenus();
  if (millis() - checkepoch > 25000)
  {
    getEpoch();
    checkepoch = millis();
  }

  if ((userFlag == true) || (vechileFlag == true))
  {
    if ((millis() - flagcheckMillis < 15000) && (userFlag == true) && (vechileFlag == true))
    {
      Serial.println("BOTH ARE ASSIGNED");

      Serial2.print("page page1");
      Serial2.write(0xff);
      Serial2.write(0xff);
      Serial2.write(0xff);
      showPage1Reason();

      Serial.println("MAIN MENU WILL BE OPENED");

      userFlag = false;
      vechileFlag = false;
    }
    else
    {
      if (millis() - flagcheckMillis > 15000)
      {
        Serial.println("FLAG RESET");
        Serial.println("SCAN AGAIN");
        showUserTag("USER TAG");
        showVehicleTag("VECHICLE TAG");
        userFlag = false;
        vechileFlag = false;
      }
    }
  }
  else
  {
    //  Serial.println("ENTER SECOND TAG");
  }
//##########  CONDITION FOR FLOW METER
  if(flowFlag == true){
       value=CheckFlow(calibrationFactor);
dtostrf(value, 5, 2, buffer);  // Convert the float to a string with 5 digits, 2 decimal places, and store it in the buffer
Serial.println(buffer);
String a=buffer;
      p2tb1.setText(a.c_str());
  }
  else{
    finalLiters=0;
  }

  if(postFlag == true){
    String postStr="{\"staid\":\""+(String)station_ID+"\",\"urfid\":\""+(String)userArray[0]+"\",\"vrfid\":\""+(String)vechileArray[0]+"\",\"rone\":\""+(String)reasonArray[0]+"\",\"rtwo\":\""+(String)reasonArray[1]+"\",\"rthree\":\""+(String)reasonArray[2]+"\",\"rfour\":\""+(String)reasonArray[3]+"\",\"rfive\":\""+(String)reasonArray[4]+"\",\"km\":\""+(String)inputKelo+"\",\"fuel\":\""+(String)finalLiters+"\",\"epoch\":\""+(String)rtc.getEpoch()+"\"}";


 if (WiFi.status() != WL_CONNECTED)
  {
  String time=(String)rtc.getEpoch();
String fileName = "/uploadData/" + time + ".json";
   writeJsonToSpiff(fileName.c_str(), postStr.c_str());
  }else{
postData(postStr);
Serial.println("POSTING");
String a="Sucessfully Posted";
   p2tb1.setText(a.c_str());
     digitalWrite(pump_RELAY,LOW);
   delay(5000);

  }
  postFlag = false;
  counter=0;
  inputKelo=0;
  finalLiters=0;
  value=0;
  
  for (int i=0;i<10;i++){
     char buffer[i]="0";
  }

  Serial2.print("page page0");
          Serial2.write(0xff);
          Serial2.write(0xff);
          Serial2.write(0xff);
  }
}