FastLED updates for adafruit FEATHER M4 and fixes to ITSBITSY M4 compiles
  SAMD51

Tested on 
  - FEATHER M4 with DOTSTAR and neopixel strips
  - Seeed Wio Terminal and WS2812B and APA102 LED strips using either SPI or GPIO pins

