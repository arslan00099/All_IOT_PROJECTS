#include <WiFi.h>
#include <ESPAsyncWebServer.h>
#include <SPIFFS.h>
#include <Preferences.h>
#include <Arduino_JSON.h>


Preferences preferences;
JSONVar readings;


// Replace with your network credentials
const char* ssid = "Neo";
const char* password = "12345678";

// Create AsyncWebServer object on port 80
AsyncWebServer server(80);
const char* PARAM_INPUT_1 = "output";
const char* PARAM_INPUT_2 = "state";
String ssidp;
String passwordp;





const char index_html[] PROGMEM = R"rawliteral(
<!DOCTYPE HTML><!DOCTYPE HTML>
<!DOCTYPE HTML>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body {
            background-image: url('bg');
            background-size: cover;
            background-position: center;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin-top: 100px;
        }

        button {
            color: #fff !important;
            text-transform: uppercase;
            text-decoration: none;
            background: #000;
            border: 2px solid #ffffff;
            padding: 10px;
            border-radius: 30px;
            display: inline-block;
            border: 2px solid #ffffff;
            transition: all 0.4s ease 0s;
            width: 500px;
            font-size: 40px;
            font-family: "Times New Roman", Times, serif;
            font-weight: bold;
        }

        button:hover {
            text-shadow: 0px 0px 6px rgba(255, 255, 255, 1);
            -webkit-box-shadow: 0px 5px 40px -10px rgba(0, 0, 0, 0.57);
            -moz-box-shadow: 0px 5px 40px -10px rgba(0, 0, 0, 0.57);
            transition: all 0.4s ease 0s;
        }

        .active_state {
            background: #FF0000;
        }
    </style>
</head>
<body>
    <center>
        <button name="one" id="one" value="" class="antenna_button inactive_state" onclick="toggleActiveState(this, 'ANTENNA 1')" style="margin-right: 250px; margin-top: 20px;">loading...</button><br><br>
        <button name="two" id="two" value="" class="antenna_button inactive_state" onclick="toggleActiveState(this, 'ANTENNA 2')" style="margin-left: 250px;">loading...</button><br><br>
        <button name="three" id="three" value="" class="antenna_button inactive_state" onclick="toggleActiveState(this, 'ANTENNA 3')" style="margin-right: 250px;">loading...</button><br><br>
        <button name="four" id="four" value="" class="antenna_button inactive_state" onclick="toggleActiveState(this, 'ANTENNA 4')" style="margin-left: 250px;">loading...</button><br><br>
        <button name="five" id="five" value="" class="antenna_button inactive_state" onclick="toggleActiveState(this, 'ANTENNA 5')" style="margin-right: 250px;">loading...</button><br><br>
    </center>
    <img id="settingImage" src="setting" style="margin-left: 50px; cursor: pointer;" onclick="onSettingImageClick()">
    <script>
        function toggleActiveState(clickedButton, buttonName) {
            // Reset all buttons to inactive_state
            var buttons = document.querySelectorAll('.antenna_button');
            buttons.forEach(function (button) {
                button.classList.remove('active_state');
                button.classList.add('inactive_state');
            });

            // Toggle the state of the clicked button
            if (clickedButton.classList.contains('inactive_state')) {
                clickedButton.classList.remove('inactive_state');
                clickedButton.classList.add('active_state');
            } else {
                clickedButton.classList.remove('active_state');
                clickedButton.classList.add('inactive_state');
            }

            // Log which button is clicked
            console.log(buttonName + " is clicked");
             var a = "message";
                var xhr = new XMLHttpRequest();
                xhr.open("GET", "/update?output=" + a + "&state=" + buttonName, true);
                xhr.send();
        }

        function onSettingImageClick() {
            // Add your logic for the image click event here
            console.log("Setting image clicked!");
                  var xhr = new XMLHttpRequest();
                setTimeout(function () { window.open("/wifi_open", "_self"); }, 1000);
        }

         window.onload = function () {
                var xhr = new XMLHttpRequest();
                xhr.onreadystatechange = function () {
                  if (this.readyState == 4 && this.status == 200) {
                    var myObj = JSON.parse(this.responseText);
                    console.log(myObj);
                    var assid = myObj.ssid;
                    var pass = myObj.pass;
                    var onee =myObj.one;
                    var twoo=myObj.two;
                    var threee=myObj.three;
                    var fourr=myObj.four;
                    var fivee=myObj.five;                   
                    
                  document.getElementById("one").innerHTML = onee;
            document.getElementById("two").innerHTML = twoo;
            document.getElementById("three").innerHTML = threee;
            document.getElementById("four").innerHTML = fourr;
            document.getElementById("five").innerHTML = fivee;


                  }
                };
                xhr.open("GET", "/getnames", true);
                xhr.send();
              }
    </script>
</body>
</html>

)rawliteral";

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

//############################################################################################################

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

 const char wifi_html[] PROGMEM = R"rawliteral(
    <!DOCTYPE HTML>
    <html>

    <head>
      <title>ESP Web Server</title>
      <meta name="apple-mobile-web-app-capable" content="yes">
      <meta content="text/html; charset=utf-8" http-equiv="content-type">
      <meta name="viewport" content="width=device-width, intial-scale=1">
      <style>
        html {
          font-family: Arial;
          display: inline-block;
          text-align: center;
        }

        body {
            background-image: url('bg');
            background-size: cover;
            background-position: center;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin-top: 100px;
        }


      

        .card-grid {
          max-width: 400px;
          margin: 0 auto;
          display: grid;

          grid-gap: 2rem;
          grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        }

        .card {
          background-color: white;
          border-radius: 10px;
          margin-top:110px;
          box-shadow: 2px 2px 12px 1px rgba(140, 140, 140, .5);
        }

        .maindiv {
          background-color: white;
          margin-top: 20px;
          border-radius: 40px;
          width: 550px;
          box-shadow: 2px 2px 12px 1px rgba(140, 140, 140, .5);
        }

      
      </style>
      <center>
      

    </head>
  


    <body>
        <div class="card-grid">
          <div class="card">
            </br>
            </br>

            <table align="center" cellpadding="3" cellspacing="3" enctype="multipart/form-data">
              <td align="right">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SSID : </td>
              <td> <input type="text" name="name" id="ssid" value="" style="height:27px ;" />
              <td></br>
            </table>
            <table align="center" cellpadding="3" cellspacing="3" enctype="multipart/form-data">
              <td align="right"> PASSWORD : </td>
              <td> <input type="text" name="name" id="passwordd" value="" style="height:27px ;" />
              <td></br>
            </table></br></br>
            <center><button onclick="postdata();" style="height: 35px;
    border-radius:10px;"><b>SAVE</b></button></center></br></br>




            <script type="text/javascript">


              function logoutButton() {
                var xhr = new XMLHttpRequest();
                xhr.open("GET", "/logout", true);
                xhr.send();
                setTimeout(function () { window.open("/logged-out", "_self"); }, 2000);
              }

              function wifiButton() {
                var xhr = new XMLHttpRequest();


                setTimeout(function () { window.open("/wifi_open", "_self"); }, 2000);
              }


              function postdata() {

                var ssidvalue = document.getElementById("ssid").value;


                var a = "SSID";
                var xhr = new XMLHttpRequest();
                xhr.open("GET", "/DATA?output=" + a + "&state=" + ssidvalue, true);
                xhr.send();

                var passwordvalue = document.getElementById("passwordd").value;

                var b = "PASSWORD";
                var xhr = new XMLHttpRequest();
                xhr.open("GET", "/DATA?output=" + b + "&state=" + passwordvalue, true);
                xhr.send();


              }

              window.onload = function () {
                var xhr = new XMLHttpRequest();
                xhr.onreadystatechange = function () {
                  if (this.readyState == 4 && this.status == 200) {
                    var myObj = JSON.parse(this.responseText);
                    console.log(myObj);
                    var assid = myObj.ssid;
                    var pass = myObj.pass;
                    ssid.value = assid;
                    passwordd.value = pass;

                  }
                };
                xhr.open("GET", "/readings", true);
                xhr.send();
              }

               function onSettingImageClick() {
            // Add your logic for the image click event here
            console.log("BACK clicked");
                  var xhr = new XMLHttpRequest();
                setTimeout(function () { window.open("/", "_self"); }, 1000);
        }

            </script>

            </br>
            </br>

          </div>
          </br></br>
        </div>
         </center>
        <img id="settingImage" src="back" style="margin-left: 50px; cursor: pointer;" onclick="onSettingImageClick()">
 

    </body>
   
   

    </html>
    )rawliteral";

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

//############################################################################################################

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

 const char names_html[] PROGMEM = R"rawliteral(
    <!DOCTYPE HTML>
    <html>

    <head>
      <title>ESP Web Server</title>
      <meta name="apple-mobile-web-app-capable" content="yes">
      <meta content="text/html; charset=utf-8" http-equiv="content-type">
      <meta name="viewport" content="width=device-width, intial-scale=1">
      <style>
        html {
          font-family: Arial;
          display: inline-block;
          text-align: center;
        }

        body {
            background-image: url('bg');
            background-size: cover;
            background-position: center;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin-top: 100px;
        }


      

        .card-grid {
          max-width: 400px;
          margin: 0 auto;
          display: grid;

          grid-gap: 2rem;
          grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        }

        .card {
          background-color: white;
          border-radius: 10px;
          margin-top:110px;
          box-shadow: 2px 2px 12px 1px rgba(140, 140, 140, .5);
        }

        .maindiv {
          background-color: white;
          margin-top: 20px;
          border-radius: 40px;
          width: 550px;
          box-shadow: 2px 2px 12px 1px rgba(140, 140, 140, .5);
        }

      
      </style>
      <center>
      

    </head>
  


    <body>
        <div class="card-grid">
          <div class="card">
         

          <table align="center" cellpadding="3" cellspacing="3" enctype="multipart/form-data">
              <td align="right"> Antenna 1 : </td>
              <td> <input type="text" name="one" id="one" value="" style="height:27px ;" />
              <td>
            </table>
            <table align="center" cellpadding="3" cellspacing="3" enctype="multipart/form-data">
              <td align="right"> Antenna 2 : </td>
              <td> <input type="text" name="two" id="two" value="" style="height:27px ;" />
              <td>
            </table>
             <table align="center" cellpadding="3" cellspacing="3" enctype="multipart/form-data">
              <td align="right"> Antenna 3 : </td>
              <td> <input type="text" name="three" id="three" value="" style="height:27px ;" />
              <td>
            </table>
             <table align="center" cellpadding="3" cellspacing="3" enctype="multipart/form-data">
              <td align="right"> Antenna 4 : </td>
              <td> <input type="text" name="four" id="four" value="" style="height:27px ;" />
              <td>
            </table>
             <table align="center" cellpadding="3" cellspacing="3" enctype="multipart/form-data">
              <td align="right"> Antenna 5 : </td>
              <td> <input type="text" name="five" id="five" value="" style="height:27px ;" />
              <td>
            </table></br>
            <center><button onclick="savenames();" style="height: 35px;
    border-radius:10px;"><b>SAVE</b></button></center>




            <script type="text/javascript">

              function savenames() {
                var onee = document.getElementById("one").value;
                var twoo = document.getElementById("two").value;
                var three = document.getElementById("three").value;
                var fourr = document.getElementById("four").value;
                var fivee = document.getElementById("five").value;
                
                var myJSON = {
        "one": onee,
        "two": twoo,
        "three": three,
        "four": fourr,
        "five": fivee
    };
     var jsonString = JSON.stringify(myJSON);

                var b = "names";
                var xhr = new XMLHttpRequest();
                xhr.open("GET", "/DATA?output=" + b + "&state=" + jsonString, true);
                xhr.send();


              }

              window.onload = function () {
                var xhr = new XMLHttpRequest();
                xhr.onreadystatechange = function () {
                  if (this.readyState == 4 && this.status == 200) {
                    var myObj = JSON.parse(this.responseText);
                    console.log(myObj);
                    var assid = myObj.ssid;
                    var pass = myObj.pass;
                    var onee =myObj.one;
                    var twoo=myObj.two;
                    var threee=myObj.three;
                    var fourr=myObj.four;
                    var fivee=myObj.five;                   
                    
                    one.value = onee;
                    two.value= twoo;
                    three.value=threee;
                    four.value=fourr;
                    five.value=fivee;


                  }
                };
                xhr.open("GET", "/getnames", true);
                xhr.send();
              }

               function onSettingImageClick() {
            // Add your logic for the image click event here
            console.log("BACK clicked");
                  var xhr = new XMLHttpRequest();
                setTimeout(function () { window.open("/", "_self"); }, 1000);
        }

            </script>

            </br>
            </br>

          </div>
          </br></br>
        </div>
         </center>
        <img id="settingImage" src="back" style="margin-left: 50px; cursor: pointer;" onclick="onSettingImageClick()">
 

    </body>
   
   

    </html>
    )rawliteral";






void getpreferences()
{
  preferences.begin("my-app", false);
  ssidp = preferences.getString("SSID");
  passwordp = preferences.getString("PASSWORD");
  preferences.end();
}

String getssidandpassword()
{
  readings["ssid"] = (ssidp);
  readings["pass"] = (passwordp);
  
  String jsonString = JSON.stringify(readings);
  Serial.println(jsonString);
  return jsonString;
}

String getnames(){
   preferences.begin("my_preferences", false);
  String jsonData = preferences.getString("json_data", "");
   return jsonData;
}

void setup(){
  // Serial port for debugging purposes
  Serial.begin(115200);
  getpreferences();
  // Connect to Wi-Fi
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(1000);
    Serial.println("Connecting to WiFi..");
  }
  if(!SPIFFS.begin()){
        Serial.println("An Error has occurred while mounting SPIFFS");
        return;
  }

  // Print ESP32 Local IP Address
  Serial.println(WiFi.localIP());

  // Route for root / web page

  server.on("/", HTTP_GET, [](AsyncWebServerRequest *request){
    request->send_P(200, "text/html", index_html);
  });

  server.on("/wifi_open", HTTP_GET, [](AsyncWebServerRequest *request)
  { request->send_P(200, "text/html", wifi_html); 
  });

    server.on("/names", HTTP_GET, [](AsyncWebServerRequest *request)
  { request->send_P(200, "text/html", names_html); 
  });
  
  server.on("/bg", HTTP_GET, [](AsyncWebServerRequest *request){
    request->send(SPIFFS, "/bg.jpg", "image/jpg");
  });

    server.on("/back", HTTP_GET, [](AsyncWebServerRequest *request){
    request->send(SPIFFS, "/back.png", "image/png");
  });

    server.on("/setting", HTTP_GET, [](AsyncWebServerRequest *request){
    request->send(SPIFFS, "/setting.png", "image/png");
  });

    server.on("/readings", HTTP_GET, [](AsyncWebServerRequest *request)
            {
    String json = getssidandpassword();
    request->send(200, "application/json", json);
    json = String(); });

     server.on("/getnames", HTTP_GET, [](AsyncWebServerRequest *request)
            {
    String json = getnames();
    request->send(200, "application/json", json);
    json = String(); });

   server.on("/update", HTTP_GET, [] (AsyncWebServerRequest *request) {
    String inputMessage1;
    String inputMessage2;
    // GET input1 value on <ESP_IP>/update?output=<inputMessage1>&state=<inputMessage2>
    if (request->hasParam(PARAM_INPUT_1) && request->hasParam(PARAM_INPUT_2)) {
      inputMessage1 = request->getParam(PARAM_INPUT_1)->value();
      inputMessage2 = request->getParam(PARAM_INPUT_2)->value();
      digitalWrite(inputMessage1.toInt(), inputMessage2.toInt());
    }
    else {
      inputMessage1 = "No message sent";
      inputMessage2 = "No message sent";
    }
    Serial.print("KEY : ");
    Serial.print(inputMessage1);
    Serial.print(" VALUE : ");
    Serial.println(inputMessage2);
    if(inputMessage1.indexOf('message')>-1){
    
    
        }
    request->send(200, "text/plain", "OK");
  });


   server.on("/DATA", HTTP_GET, [](AsyncWebServerRequest *request)
            {
              String inputMessage1;
              String inputMessage2;

              // GET input1 value on <ESP_IP>/update?output=<inputMessage1>&state=<inputMessage2>
              if (request->hasParam(PARAM_INPUT_1) && request->hasParam(PARAM_INPUT_2))
              {
                inputMessage1 = request->getParam(PARAM_INPUT_1)->value();
                inputMessage2 = request->getParam(PARAM_INPUT_2)->value();
                if (inputMessage1.indexOf("names") > -1)
                {
                preferences.begin("my-app", false);
                preferences.putString("json_data", inputMessage2);
                preferences.end();
                
                }
              }
              else
              {
                inputMessage1 = "No message sent";
                inputMessage2 = "No message sent";
              }
              Serial.print("KEY: ");
              Serial.print(inputMessage1);
              Serial.print(" Data: ");
              Serial.println(inputMessage2);
              request->send(200, "text/plain", "OK");
              preferences.begin("my-app", false);
              preferences.putString(inputMessage1.c_str(), inputMessage2);
              preferences.end();
              getpreferences();
            });


  server.begin();
}
 
void loop(){
  
}