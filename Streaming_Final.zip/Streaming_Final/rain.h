#define rain_PIN 32
#define thold 1500



void setuprain()
{
  pinMode(rain_PIN,INPUT);
}
