#include <WiFi.h>              // Include WiFi library
#include <PubSubClient.h>     // Include PubSubClient library
#include <HardwareSerial.h>   // Include HardwareSerial library

HardwareSerial SerialPort(2); // Initialize SerialPort object for UART2 communication

// WiFi Credentials
const char *ssid = "Neo";            // Replace with your WiFi name
const char *password = "12345678";  // Replace with your WiFi password

// MQTT Broker Settings
const char *mqtt_broker = "broker.emqx.io"; // MQTT broker address
const char *mqtt_topic = "emqx/esp32arslan"; // MQTT topic to publish/subscribe
const char *mqtt_username = "emqx";           // MQTT username
const char *mqtt_password = "public";         // MQTT password
const int mqtt_port = 1883;                   // MQTT broker port

WiFiClient espClient;               // Initialize WiFiClient object
PubSubClient mqtt_client(espClient); // Initialize PubSubClient object with WiFiClient

// Function Declarations
void connectToWiFi();               // Function to connect to WiFi
void connectToMQTT(String msg);    // Function to connect to MQTT broker
void mqttCallback(char *mqtt_topic, byte *payload, unsigned int length); // Callback function for MQTT messages

void setup() {
    Serial.begin(115200);             // Start serial communication at 115200 baud rate
    SerialPort.begin(15200, SERIAL_8N1, 16, 17); // Start UART2 communication

    connectToWiFi();                  // Connect to WiFi network
    mqtt_client.setServer(mqtt_broker, mqtt_port); // Set MQTT broker server and port
    mqtt_client.setKeepAlive(60);     // Set MQTT keep-alive interval
    mqtt_client.setCallback(mqttCallback); // Set callback function for MQTT messages
    connectToMQTT("Sucessfully connected"); // Connect to MQTT broker and publish a message
}

void connectToWiFi() {
    WiFi.begin(ssid, password);      // Connect to WiFi network with provided credentials
    Serial.print("Connecting to WiFi");
    while (WiFi.status() != WL_CONNECTED) { // Wait until connected to WiFi
        delay(500);
        Serial.print(".");
    }
    Serial.println("\nConnected to WiFi");
}

void connectToMQTT(String msg) {
    while (!mqtt_client.connected()) { // Loop until connected to MQTT broker
        String client_id = "esp32-client-" + String(WiFi.macAddress()); // Create client ID
        Serial.printf("Connecting to MQTT Broker as %s.....\n", client_id.c_str());
        if (mqtt_client.connect(client_id.c_str(), mqtt_username, mqtt_password)) { // Connect to MQTT broker with client ID, username, and password
            Serial.println("Connected to MQTT broker");
            mqtt_client.subscribe(mqtt_topic); // Subscribe to MQTT topic
            mqtt_client.publish(mqtt_topic, msg.c_str()); // Publish message upon successful connection
        } else {
            Serial.print("Failed, rc=");
            Serial.print(mqtt_client.state()); // Print MQTT connection state
            Serial.println(" try again in 5 seconds");
            delay(5000); // Wait 5 seconds before retrying connection
        }
    }
}

void mqttCallback(char *mqtt_topic, byte *payload, unsigned int length) {
    Serial.print("Message received on mqtt_topic: ");
    Serial.println(mqtt_topic); // Print MQTT topic
    Serial.print("Message: ");
    for (unsigned int i = 0; i < length; i++) { // Loop through received message payload
        Serial.print((char) payload[i]); // Print each character of payload
    }
    Serial.println("\n-----------------------");
}

void loop() {
    static String receivedData = ""; // Static variable to store received data

    if (SerialPort.available() > 0) { // Check if data is available on UART2
        char incomingChar = SerialPort.read(); // Read incoming character

        if (incomingChar == '\n') { // Check if end of line is received
            Serial.print("Received: ");
            Serial.println(receivedData); // Print received data
            mqtt_client.publish(mqtt_topic, receivedData.c_str()); // Publish received data to MQTT topic
            receivedData = ""; // Clear received data for next message
        } else {
            receivedData += incomingChar; // Add incoming character to received data buffer
        }
    }

    if (!mqtt_client.connected()) { // Check if MQTT client is not connected
        connectToMQTT("again connected"); // Reconnect to MQTT broker
    }
    mqtt_client.loop(); // Maintain MQTT connection
}
