#include <Arduino.h>

#include "index.h"
#include <Arduino_JSON.h>
boolean sendFlag=false;

JSONVar readings;
const char *PARAM_INPUT_1 = "output";
const char *PARAM_INPUT_2 = "state";

AsyncWebServer server(80);

String getSensorReadings()
{

//     int minValue = -100; // Set your desired minimum value (negative)
//   int maxValue = 100;  // Set your desired maximum value (positive)

//   int randomValue = random(minValue, maxValue + 1); // Generate a random number


if(sendFlag){
  readings["total"] =String ("10");
  readings["up"] =String ("20");
  readings["down"] =String("30");
  readings["left"] = String("40");
  readings["right"] = String("50");
}

else {
 readings["total"] =String ("0");
  readings["up"] =String ("0");
  readings["down"] =String("0");
  readings["left"] = String("0");
  readings["right"] = String("0");
}
  String jsonString = JSON.stringify(readings);
  Serial.println(jsonString);
  return jsonString;
}

void setup() {
    Serial.begin(115200);
    WiFi.begin(ssid, password);
    while (WiFi.status() != WL_CONNECTED) {
        delay(1000);
        Serial.println("Connecting to WiFi...");
    }
    Serial.println("Connected to WiFi");
     Serial.println(WiFi.localIP());

    server.on("/", HTTP_GET, [](AsyncWebServerRequest *request){
        request->send(200, "text/html", htmlContent);
    });
      server.on("/readings", HTTP_GET, [](AsyncWebServerRequest *request)
            {
    String json = getSensorReadings();
    request->send(200, "application/json", json);
    json = String(); });

    server.on("/DATA", HTTP_GET, [](AsyncWebServerRequest *request)
            {
              String inputMessage1;
              String inputMessage2;

              // GET input1 value on <ESP_IP>/update?output=<inputMessage1>&state=<inputMessage2>
              if (request->hasParam(PARAM_INPUT_1) && request->hasParam(PARAM_INPUT_2))
              {
                inputMessage1 = request->getParam(PARAM_INPUT_1)->value();
                inputMessage2 = request->getParam(PARAM_INPUT_2)->value();
                if (inputMessage1.indexOf("start") > -1)
                {
                 sendFlag=true;
                 Serial.println("SEND FLAG TRUE");
                }
                 if (inputMessage1.indexOf("stop") > -1)
                {
                 sendFlag=false;
                  Serial.println("SEND FLAG FALSE");
                }
              }
              else
              {
                inputMessage1 = "No message sent";
                inputMessage2 = "No message sent";
              }
              Serial.print("KEY: ");
              Serial.print(inputMessage1);
              Serial.print(" Data: ");
              Serial.println(inputMessage2);
              request->send(200, "text/plain", "OK");
           
            });


    server.begin();
}

void loop() {
  
}
